import edu.princeton.cs.algs4.WeightedQuickUnionUF;

import java.util.HashSet;
import java.util.Set;

public class Percolation {

    private final boolean[] sites;
    //    private final boolean[] groundedRoots;
    private final Set<Integer> groundedRoots;
    private final int size;
    private final int totalSites;
    private final WeightedQuickUnionUF qufWaterSource;
    //    private final WeightedQuickUnionUF qufRoot;
    private int openSites = 0;
    private boolean percolates = false;

    public Percolation(int n) {
        if (n <= 0) {
            throw new IllegalArgumentException();
        }
        this.totalSites = n * n;
        this.sites = new boolean[totalSites];
//        this.groundedRoots = new boolean[n];
        this.groundedRoots = new HashSet<>();
        this.size = n;
        this.qufWaterSource = new WeightedQuickUnionUF(totalSites + 1);
//        this.qufRoot = new WeightedQuickUnionUF(totalSites + 1);
    }

    // opens the site (row, col) if it is not open already
    public void open(int row, int col) {
        checkInput(row, col);
        int currentSite = getTargetPlace(row, col);
        if (!sites[currentSite]) {
            openSites++;
            sites[currentSite] = true;
            if (col != 1) {
                linkLeft(currentSite);
            }
            if (col < size) {
                linkRight(currentSite);
            }
            if (row != 1) {
                linkTop(currentSite);
            } else {
                linkWaterSource(currentSite);
            }
            if (row < size) {
                linkBottom(currentSite);
            } else {
                linkRoot(currentSite);
            }
            tryToPercolate(currentSite);
        }
    }

    private void linkWaterSource(int currentSite) {
        qufWaterSource.union(currentSite, totalSites);
    }

    private void linkRoot(int currentSite) {
        groundedRoots.add(qufWaterSource.find(currentSite));
//                qufRoot.union(currentSite, totalSites);
    }

    private void checkInput(int row, int col) {
        if (row <= 0 || row > size) {
            throw new IllegalArgumentException();
        }
        if (col <= 0 || col > size) {
            throw new IllegalArgumentException();
        }
    }

    private void linkLeft(int currentSite) {
        int targetSite = currentSite - 1;
        link(currentSite, targetSite);
    }

    private void linkRight(int currentSite) {
        int targetSite = currentSite + 1;
        link(currentSite, targetSite);
    }

    private void linkTop(int currentSite) {
        int targetSite = currentSite - size;
        link(currentSite, targetSite);
    }

    private void linkBottom(int currentSite) {
        int targetSite = currentSite + size;
        link(currentSite, targetSite);
    }

    private void link(int currentSite, int targetSite) {
        if (sites[targetSite]) {
            int currentRoot = qufWaterSource.find(currentSite);
            int targetRoot = qufWaterSource.find(targetSite);
            qufWaterSource.union(currentSite, targetSite);
            if (!percolates) {
                if (groundedRoots.contains(currentRoot) ^ groundedRoots.contains(targetRoot)) {
                    groundedRoots.remove(currentRoot);
                    groundedRoots.remove(targetRoot);
                    groundedRoots.add(qufWaterSource.find(currentSite));
                }
            }
//            qufRoot.union(currentSite, targetSite);
        }
    }

    private void tryToPercolate(int currentSite) {
        if (!percolates && isFull(currentSite) && groundedRoots.contains(qufWaterSource.find(currentSite))) {
            percolates = true;
        }
//        if (!percolates && isFull(currentSite) && isConnectedToRoot(currentSite)) {
//            percolates = true;
//        }
    }

    public boolean isOpen(int row, int col) {
        checkInput(row, col);
        return sites[getTargetPlace(row, col)];
    }

    public boolean isFull(int row, int col) {
        checkInput(row, col);
        return isFull(getTargetPlace(row, col));
    }

    private boolean isFull(int currentSite) {
        return isConnectedToWaterSource(currentSite);
    }

    private int getTargetPlace(int row, int col) {
        return (row - 1) * size + col - 1;
    }

    public int numberOfOpenSites() {
        return openSites;
    }

    public boolean percolates() {
        return percolates;
    }

    private boolean isConnectedToWaterSource(int i) {
        return qufWaterSource.find(i) == qufWaterSource.find(totalSites);
    }

//    private boolean isConnectedToRoot(int i) {
//        return qufRoot.find(i) == qufRoot.find(totalSites);
//    }

    public static void main(String[] args) {
        // Do nothing
    }


}
